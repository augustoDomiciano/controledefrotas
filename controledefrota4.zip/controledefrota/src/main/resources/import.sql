insert into veiculo (id, marca, placa) values (1022, 'Ford', 'adas1212');
insert into veiculo (id, marca, placa) values (1023, 'Honda', 'adas1246');
insert into veiculo (id, marca, placa) values (1024, 'Jeep', 'adas1221');