package com.cdf.controledefrota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ControledefrotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ControledefrotaApplication.class, args);
	}

}
